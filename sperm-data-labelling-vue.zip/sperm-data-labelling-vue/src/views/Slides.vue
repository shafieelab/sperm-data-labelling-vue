<template>
  <v-container>
    <v-layout class="temp" row wrap>
      <v-flex md12 xs12>
        <!--<v-layout align-space-around justify-space-around  row fill-height fill-width wrap>-->
        <!--<v-flex md12 xs4>-->
        <!--<v-btn color="success">Normal</v-btn>-->
        <!--</v-flex>-->
        <!--<v-flex md12 xs4>-->
        <!--<v-btn color="success">Success</v-btn>-->
        <!--</v-flex>-->
        <!--<v-flex md12 xs4>-->
        <!--<v-btn color="success">Success</v-btn>-->
        <!--</v-flex>-->

        <!--<v-btn color="success">Success</v-btn>-->
        <!--<v-btn color="success">Success</v-btn>-->
        <!--<v-btn color="success">Success</v-btn>-->
        <!--<v-btn color="success">Success</v-btn>-->
        <!--<v-btn color="success">Success</v-btn>-->
        <!--<v-btn color="success">Success</v-btn>-->
        <!--<v-btn color="success">Success</v-btn>-->
        <!--<v-btn color="success">Success</v-btn>-->
        <!--<v-layout align-space-around justify-space-around  row fill-height fill-width>-->
        <!--<v-btn color="success">Previous</v-btn>-->
        <!--<v-btn color="success">Mark</v-btn>-->
        <!--<v-btn color="success">Next</v-btn>-->
        <!--</v-layout>-->

        <!--</v-layout>-->

        <v-item-group>
          <v-container grid-list-md>
            <v-layout wrap>
              <!--{{$route.params.id}}-->

              <v-flex v-for="n in Active" :key="n" xs3 md3>
                <v-item>
                  <v-hover open-delay="200">
                    <v-card
                      class="d-flex align-center card-custom"
                      light
                      height="200"
                      @click="give_label(n)"
                    >
                      <div width="100%" height="100%" style="text-align:center">
                        {{ n }}
                      </div>
                    </v-card>
                  </v-hover>
                </v-item>
              </v-flex>
            </v-layout>
          </v-container>
        </v-item-group>
      </v-flex>

      <v-main>
        <v-container>
          <v-row>
            <v-col v-for="n in Active" :key="n" cols="4" @click="give_label(n)">
              <v-card
                class="mx-auto"
                color="#26c6da"
                dark
                max-width="400"
              >
                <v-card-title>
                  <v-icon
                    large
                    left
                  >
                    mdi-twitter
                  </v-icon>
                  <span class="title font-weight-light">Slide</span>
                </v-card-title>

                <v-card-text class="headline font-weight-bold">
                  "Turns out semicolon-less style is easier and safer in TS because most gotcha edge cases are type invalid as well."
                </v-card-text>

                <v-card-actions>
                  <v-list-item class="grow">
                    <v-list-item-avatar color="grey darken-3">
                      <v-img
                        class="elevation-6"
                        alt=""
                        src="https://avataaars.io/?avatarStyle=Transparent&topType=ShortHairShortCurly&accessoriesType=Prescription02&hairColor=Black&facialHairType=Blank&clotheType=Hoodie&clotheColor=White&eyeType=Default&eyebrowType=DefaultNatural&mouthType=Default&skinColor=Light"
                      ></v-img>
                    </v-list-item-avatar>

                    <v-list-item-content>
                      <v-list-item-title>Evan You</v-list-item-title>
                    </v-list-item-content>

                    <v-row
                      align="center"
                      justify="end"
                    >
                      <v-icon class="mr-1">
                        mdi-heart
                      </v-icon>
                      <span class="subheading mr-2">256</span>
                      <span class="mr-1">·</span>
                      <v-icon class="mr-1">
                        mdi-share-variant
                      </v-icon>
                      <span class="subheading">45</span>
                    </v-row>
                  </v-list-item>
                </v-card-actions>
              </v-card>            </v-col>
          </v-row>
        </v-container>
      </v-main>
    </v-layout>
  </v-container>
</template>

<script>
// import * as Buffer from "vuetify";

const axios = require("axios");
import store from "../store";

export default {
  data: () => ({
    cors: "https://cors-anywhere.herokuapp.com/",
    sperm_image: null,
    username: "",
    Active: [],
    label: "",
    imageno: "",
    // slide: "",
    image_name: "",
    current_slide: ""
  }),
  computed: {
    get_user() {
      return store.state.userId;
    }
  },
  watch: {},

  created() {
    console.log("Created");
    this.give_slides();
    this.username = store.state.userId;

    console.log("Username: ", this.username);
  },
  methods: {
    give_slides: function() {
      const get_sli = "http://127.0.0.1:5000/getslides";
      axios
        // .post(this.cors + get_sli, {
        .post(get_sli, {
          headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers":
              "Origin, X-Requested-With, Content-Type, Accept"
          }
        })

        .then(response => {
          console.log(response);
          this.Active = response.data.slides.split(";");
          // var res = response.data.user

          // dispatch({type: FOUND_USER, data: response.data[0]})
        })
        .catch(error => {
          this.resp = error;
          console.error(error);

          // dispatch({type: ERROR_FINDING_USER})
        });
    },
    give_label: function(temp) {
      this.current_slide = temp;
      store.commit("store_current_slide", this.current_slide);

      this.$router.push({
        // path: `/slide/${this.current_slide}/${this.username}`

        path: "/label"
      });
    }
  }
};
</script>

<style>
.card-custom {
  height: 100px;
}
@media (max-width: 425px) {
  .temp {
    flex-direction: column;
  }
  .card-custom {
    height: 30px;
  }

  .image {
    /* object-fit: cover; */
    /* max-height: 60vh; */
    /* height: 30px; */
    /* width: 30px; */
    /* width: 100v÷w; */
  }
}
.image {
  /* object-fit: cover; */
  /* max-height: 60vh; */
  /* height: 80vh; */
  /* width: 80vh; */
  /* width: 100v÷w; */
}
</style>
<style lang="sass" scoped>
.v-card.on-hover.theme--dark
  background-color: rgba(#FFF, 0.8)
  >.v-card__text
    color: #000
</style>
