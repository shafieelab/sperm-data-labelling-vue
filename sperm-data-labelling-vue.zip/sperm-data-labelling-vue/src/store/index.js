import Vue from "vue";
import Vuex from "vuex";
// const axios = require("axios");

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    userId: null,
    current_slide: null,
  },
  mutations: {
    store_user(state, userId) {
      // state.idToken = userData.token;
      state.userId = userId;
    },
    store_current_slide(state, slide) {
      // state.idToken = userData.token;
      state.current_slide = slide;
    }
  },
  actions: {
    // login ({commit}, authData) {
    //
    //   axios
    //     // .post("https://cors-anywhere.herokuapp.com/" + url + "/login", data, {
    //     .post("http://127.0.0.1:5000/login", data, {
    //       headers: {
    //         "Content-Type": "application/json",
    //         "Access-Control-Allow-Origin": "*",
    //         "Access-Control-Allow-Headers":
    //           "Origin, X-Requested-With, Content-Type, Accept"
    //       }
    //     })
    //
    //
    //
    //
    //   axios.post('/verifyPassword?key=[add your Firebase API key here]',{
    //     email: authData.email,
    //     password: authData.password,
    //     returnSecureToken: truen      })
    //     .then(res => {
    //       console.log(res)
    //     })
    //     .catch(error => console.log(error))
    // },
  },

  getters: {
    // doneTodos: state => {
    //   return state.todos.filter(todo => todo.done);
    // }
  },
  modules: {}
});
