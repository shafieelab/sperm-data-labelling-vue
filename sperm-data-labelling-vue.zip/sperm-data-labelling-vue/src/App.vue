<template>
  <div id="app">
    <v-app-bar app shrink-on-scroll>
      <v-app-bar-nav-icon></v-app-bar-nav-icon>

      <v-toolbar-title>Shafiee Lab - Image Annotator</v-toolbar-title>
      <v-spacer></v-spacer>
      <v-btn icon>
        <v-icon>mdi-dots-vertical</v-icon>
      </v-btn>
    </v-app-bar>

    <v-main class="section-wrapper">
      <!--<transition :name="transitionName">-->

      <!--<transition name="router-anim" enter-active-class="animated fadeInDown" leave-active-class="animated fadeOutDown">-->
      <transition name="router-anim">
        <!--<transition name="page" mode="out-in">-->

        <router-view> </router-view>
      </transition>
    </v-main>

    <AppFooter />
    <!--<div id="nav">-->
    <!--<router-link to="/">Home</router-link> |-->
    <!--<router-link to="/about">About</router-link>-->
    <!--</div>-->
  </div>
</template>

<script>
// @ is an alias to /src
import AppFooter from "@/AppFooter";

export default {
  name: "App",
  components: {
    AppFooter
    // Header
  },
  data() {
    return {
      clipped: false,
      drawer: false,
      fixed: false,
      items: [
        {
          icon: "bubble_chart",
          title: "Login",
          to: "/login"
        },
        {
          icon: "bubble_chart",
          title: "Signup",
          to: "/signup"
        }
      ],
      miniVariant: false,
      right: true,
      rightDrawer: false,
      title: "Shafiee Lab - Image annotator",
      transitionName: "slide-left"
    };
  },
  // beforeRouteUpdate (to, from, next) {
  //   const toDepth = to.path.split('/').length
  //   const fromDepth = from.path.split('/').length
  //   this.transitionName = toDepth < fromDepth ? 'slide-right' : 'slide-left'
  //   next()
  // },

  watch: {
    $route(to, from) {
      const toDepth = to.path.split("/").length;
      const fromDepth = from.path.split("/").length;
      this.transitionName = toDepth < fromDepth ? "slide-right" : "slide-left";
    }
  }
};
</script>

<style>
/*@import './assets/css/custom.css';*/

a {
  text-decoration: none;
}

.page-enter-active,
.page-leave-active {
  transition: opacity 0.5s, transform 0.5s;
}
.page-enter,
.page-leave-to {
  opacity: 0;
  /*transform: translateX(-30%);*/
}

.router-anim-enter-active {
  animation: coming 0.5s;
  animation-delay: 1s;
  opacity: 0;
}
.router-anim-leave-active {
  animation: going 0.2s;
}

@keyframes going {
  from {
    transform: translateX(0);
  }
  to {
    transform: translateX(100px);
    opacity: 0;
  }
}
@keyframes coming {
  from {
    transform: translateX(-0px);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}
</style>
